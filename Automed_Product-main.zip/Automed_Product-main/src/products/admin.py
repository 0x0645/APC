from django.contrib import admin
from souq.models import Souq

admin.site.register(Souq)
