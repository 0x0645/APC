from setting.models import Info
from django.contrib import admin
from .models import Info


admin.site.register(Info)