from django.apps import AppConfig


class SouqConfig(AppConfig):
    name = 'souq'
