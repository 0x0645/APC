from django.apps import AppConfig


class JumiaConfig(AppConfig):
    name = 'jumia'
