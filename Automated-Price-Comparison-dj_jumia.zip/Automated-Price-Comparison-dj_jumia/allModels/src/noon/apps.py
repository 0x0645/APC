from django.apps import AppConfig


class NoonConfig(AppConfig):
    name = 'noon'
